package com.sgedts.base.bean.internal;

public final class ContentWrapper<T> {
    private T content;

    public T getContent() {
        return content;
    }

    public void setContent(T content) {
        this.content = content;
    }
}

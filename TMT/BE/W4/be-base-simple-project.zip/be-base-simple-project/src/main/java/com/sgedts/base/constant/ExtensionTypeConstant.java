package com.sgedts.base.constant;

public class ExtensionTypeConstant {
    public static final String XLSX = ".xlsx";
    public static final String XLS = ".xls";
    public static final String CSV = ".csv";
}
